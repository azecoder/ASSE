import os

DATASERVICE = os.environ['DATA_SERVICE']