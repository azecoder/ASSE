from .login import login
from .users import users

blueprints = [login, users]
