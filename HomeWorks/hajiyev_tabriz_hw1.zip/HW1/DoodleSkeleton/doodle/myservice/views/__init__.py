from myservice.views.doodles import doodles


blueprints = [doodles]
